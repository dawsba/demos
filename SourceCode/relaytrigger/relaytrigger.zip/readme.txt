#Command	
#Action
#
#dec	hex
#90	5A	Get software version - returns 2 bytes, the first being the Module ID which is 10, followed by the software version
#91	5B	Get relay states - sends a single byte back to the controller, bit high meaning the corresponding relay is powered
#92	5C	Set relay states - the next single byte will set all relays states, All on = 3 (xxxxxx11) All off = 0
#100	64	All relays on
#101	65	Turn relay 1 on
#102	66	Turn relay 2 on
#110	6E	All relays off
#111	6F	Turn relay 1 off
#112	70	Turn relay 2 off

#USAGE usb-relays.exe [comport] [command(dec)]