<?PHP
  error_reporting(E_ALL);
  ini_set('display_errors', '1');
  
  require_once('_config/config.php');
  require_once(db_path.'/db.con.php');
  require_once(function_path.'/email.php');
  require_once(function_path.'/xml.php');
  require_once(db_path.'/auth.php');
  
  check_auth(); //CHECKS IP FOR AUTHENTICATION
  
  $encpath = function_path.'/'.encfile;
  if(useenc){require_once($encpath);}else{echo "ERROR IN ENC";exit(1);}
    
  require_once(function_path.'/build.php');
  
  $fields = (array) build_fields(); // GENERATES API DATA SHEET(ARRAYS)
  
  require_once(function_path.'/orderid.php');
  require_once(function_path.'/barclays.php');
  
  EPDQDirect($fields);
?>